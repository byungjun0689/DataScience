import tensorflow as tf
import matplotlib.pyplot as plt

# data set
x_data = [1., 2., 3., 4.]
y_data = [1., 3., 5., 7.]

X = [1., 2., 3.]
Y = [1., 2., 3.]
m = n_samples = len(x_data)

W = tf.placeholder(tf.float32)

hypothesis = tf.mul(X, W)

##cost = tf.reduce_sum(tf.pow(hypothesis - Y, 2)) / (m)  
cost = tf.reduce_mean(tf.square(hypothesis-Y)) ## Same as Upper line

init = tf.initialize_all_variables()

# For graphs
W_val = []
cost_val = []

sess = tf.Session()
sess.run(init)
for i in range(-30, 50):
    print(i*0.1, sess.run(cost, feed_dict={W : i*0.1}))
    W_val.append(i*0.1)
    cost_val.append(sess.run(cost, feed_dict={W: i*0.1}))
    
    