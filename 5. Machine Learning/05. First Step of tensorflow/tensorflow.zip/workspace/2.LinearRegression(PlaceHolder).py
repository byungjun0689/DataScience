import tensorflow as tf

x_data = [1., 2., 3., 4.]
y_data = [2., 4., 6., 8.]

W = tf.Variable(tf.random_uniform([1], -10000, 10000))
b = tf.Variable(tf.random_uniform([1], -10000, 10000))

X = tf.placeholder(tf.float32)
Y = tf.placeholder(tf.float32)

hypothesis = W * X + b

# cost function

cost = tf.reduce_mean(tf.square(hypothesis - Y))

# minimize

a = tf.Variable(0.1) #learning rate
optimizer = tf.train.GradientDescentOptimizer(a)
train = optimizer.minimize(cost)

# init 

init = tf.initialize_all_variables()

# launch 

sess = tf.Session()
sess.run(init)


for step in range(2001):
    sess.run(train,feed_dict={X:x_data,Y:y_data})
    if step % 20 == 0:
        print(step,sess.run(cost,feed_dict={X:x_data,Y:y_data}),sess.run(W), sess.run(b))
        
        

print(sess.run(hypothesis, feed_dict={X: 5})) # 예측 완료 
print(sess.run(hypothesis, feed_dict={X: 2.5}))