import tensorflow as tf

hello = tf.constant('Hello Tensorflow!')

sess = tf.Session()
print(sess.run(hello))


a = tf.constant(2)
b = tf.constant(3)

c = a+b

print(c)

d = a*b

print(d)

print(sess.run(c))
print(sess.run(d))