import tensorflow as tf

w = tf.Variable(tf.random_normal([3,3,1,32], stddev=0.01)) 

l = tf.nn.conv2d(X,w,strides=[1,1,1,1], padding='SAME')

l1a = 
# strides = [1, 옆으로, 아래로, 1]  몇칸씩 갈것인지. 